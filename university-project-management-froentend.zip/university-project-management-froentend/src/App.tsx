import { useEffect, useState } from 'react';
import { Route, Routes, useLocation } from 'react-router-dom';
import Loader from './common/Loader';
import PageTitle from './components/PageTitle';
import SignIn from './pages/Authentication/SignIn';
import SignUp from './pages/Authentication/SignUp';
import Calendar from './pages/Calendar';
import Chart from './pages/Chart';
import ECommerce from './pages/Dashboard/ECommerce';
import FormElements from './pages/Form/FormElements';
import FormLayout from './pages/Form/FormLayout';
import Profile from './pages/Profile';
import Tables from './pages/Tables';
import Alerts from './pages/UiElements/Alerts';
import Buttons from './pages/UiElements/Buttons';
import Login from './pages/Login/Login';
import Users from './pages/Users/Users';
import Students from './pages/Students/Students';
import Admins from './pages/Admins/Admins';
import Teachers from './pages/Teachers/Teachers';
import CreateTeacher from './pages/CreateTeacher/CreateTeacher';
import CreateProject from './pages/CreateProject';
import SchedulePage from './pages/SchedulePage';
import ProjectList from './pages/ProjectList';
import EditProfile from './pages/EditProfile';
import PreDefense from './pages/Defense/PreDefense';
import FinalDefense from './pages/Defense/FinalDefense';
import StudentProfile from './pages/Defense/StudentProfile';
import PrivateRoute from './Auth/PrivateRoute';


interface User {
  email: string;
  role: string;
  name: string;
  id: string;
}

function App() {
  const [loading, setLoading] = useState<boolean>(true);
  const { pathname } = useLocation();
  const user: User | null = JSON.parse(localStorage.getItem("user-info") || "null") as User | null;

  console.log(user?.email);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    setTimeout(() => setLoading(false), 1000);
  }, []);

  return loading ? (
    <Loader />
  ) : (
    <>
      <Routes>
        <Route
          index

          element={
            <>
              {
                user?.email ? <><PageTitle title="Profile" /><Profile /></> : <><PageTitle title="Login" /><Login /></>
              }

              {/* <PrivateRoute>
                <Profile />
              </PrivateRoute> */}
            </>
          }
        />
        <Route
          path="/calendar"
          element={
            <>
              <PageTitle title="Calendar | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <Calendar />
            </>
          }
        />
        <Route
          path="/profile"
          element={
            <>
              <PageTitle title="Profile | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <Profile />
            </>
          }
        />
        <Route
          path="/forms/form-elements"
          element={
            <>
              <PageTitle title="Form Elements | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <FormElements />
            </>
          }
        />
        <Route
          path="/forms/form-layout"
          element={
            <>
              <PageTitle title="Form Layout | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <FormLayout />
            </>
          }
        />

        <Route
          path="/users/all-users"
          element={
            <>
              <PageTitle title="Users | All Users" />
              <Users />
            </>
          }
        />

        {/* <Route
          path="/defense/pre-defense"
          element={
            <>
              <PageTitle title="pre-defense | pre-defense" />
              <Defense />
            </>
          }
        /> */}

        <Route
          path="/defense/pre-defense"
          element={
            <>
              <PageTitle title=" Defense | pre-defense" />
              <PreDefense />
            </>
          }
        />

        <Route
          path="/defense/final-defense"
          element={
            <>
              <PageTitle title="Defense | final-defense" />
              <FinalDefense />
            </>
          }
        />

        <Route
          path="/defense/student-profile/:id"
          element={
            <>
              <PageTitle title="Defense | student-profile" />
              <StudentProfile />
            </>
          }
        />

        <Route
          path="/users/students"
          element={
            <>
              <PageTitle title="Users | Students" />
              <Students />
            </>
          }
        />
        <Route
          path="/users/teachers"
          element={
            <>
              <PageTitle title="Users | Teachers" />
              <Teachers />
            </>
          }
        />
        <Route
          path="/users/admins"
          element={
            <>
              <PageTitle title="Users | Admins" />
              <Admins />
            </>
          }
        />
        <Route
          path="/create-project"
          element={
            <>
              <PageTitle title="Project | Create Project" />
              <CreateProject />
            </>
          }
        />
        <Route
          path="/project-list"
          element={
            <>
              <PageTitle title="Project |  Project List" />
              {
                (user?.role == "admin" || user?.role == "teacher") && <ProjectList />
              }
            </>
          }
        />


        <Route
          path="/schedule"
          element={
            <>
              <PageTitle title="Schedule | schedule" />
              <SchedulePage />
            </>
          }
        />

        <Route
          path="/tables"
          element={
            <>
              <PageTitle title="Tables | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <Tables />
            </>
          }
        />
        <Route
          path="/edit-profile"
          element={
            <>
              <PageTitle title="Settings | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <EditProfile />
            </>
          }
        />
        <Route
          path="/chart"
          element={
            <>
              <PageTitle title="Basic Chart | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <Chart />
            </>
          }
        />
        <Route
          path="/ui/alerts"
          element={
            <>
              <PageTitle title="Alerts | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <Alerts />
            </>
          }
        />
        <Route
          path="/ui/buttons"
          element={
            <>
              <PageTitle title="Buttons | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <Buttons />
            </>
          }
        />
        <Route
          path="/auth/signin"
          element={
            <>
              <PageTitle title="Signin | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <SignIn />
            </>
          }
        />
        <Route
          path="/auth/signup"
          element={
            <>
              <PageTitle title="Signup | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <SignUp />
            </>
          }
        />
        <Route
          path="/create-teacher"
          element={
            <>
              <PageTitle title="Create Teacher | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <CreateTeacher />
            </>
          }
        />
        <Route
          path="/login"
          element={
            <>
              <PageTitle title="Login | TailAdmin - Tailwind CSS Admin Dashboard Template" />
              <Login />
            </>
          }
        />
      </Routes>

    </>
  );
}

export default App;
