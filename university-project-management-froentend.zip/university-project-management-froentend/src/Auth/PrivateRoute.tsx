/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import React, { ReactNode, useState } from "react";
import toast from "react-hot-toast";
import { Navigate, useLocation } from "react-router-dom";
import { MoonLoader } from "react-spinners";
// import api from "../utilities/api";

interface PrivateRouteProps {
    children: ReactNode;
}

interface User {
    email: string;
    role: string;
    name: string;
    id: string;
}
const PrivateRoute: React.FC<PrivateRouteProps> = ({ children }) => {
    const [loading, setLoading] = useState(false);

    //   const token = localStorage.getItem("access-token");

    const user: User | null = JSON.parse(localStorage.getItem("user-info") || "null") as User | null;
    const location = useLocation();

    if (loading) {
        return (
            <div className="flex justify-center my-10">
                <MoonLoader color="#f97316" size={60} />
            </div>
        );
    }

    if (!user?.email) {
        toast.error('Please Login before going this page')
        return <Navigate to="/login" state={{ from: location }} replace />;
    }

    return <>{children}</>;
};

export default PrivateRoute;
