import axios from "axios";

const CLOUDINARY_PRESET = "ml_default";
const CLOUDINARY_CLOUDENAME = "dov60yweq";

interface UploadResponse {
    imageUrl: string;
    // thumbnailUrl?: string; // Uncomment if you want to use the thumbnail URL
}

const imageUploader = async (file: File): Promise<UploadResponse> => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("upload_preset", CLOUDINARY_PRESET);

    try {
        const response = await axios.post(
            `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUDENAME}/image/upload`,
            formData
        );
        const publicId = response.data.public_id;

        const imageUrl = `https://res.cloudinary.com/${CLOUDINARY_CLOUDENAME}/image/upload/f_webp/${publicId}`;
        // const thumbnailUrl = `https://res.cloudinary.com/${CLOUDINARY_CLOUDENAME}/image/upload/c_fill,h_150,w_150,f_webp/${publicId}`;

        return { imageUrl };
        // return { imageUrl, thumbnailUrl }; // Uncomment if you want to return the thumbnail URL
    } catch (error) {
        console.error("Error uploading image:", error);

        if (axios.isAxiosError(error) && error.response) {
            console.error("Error response:", error.response.data);
        }

        throw error; // Rethrow the error to handle it further up the call stack
    }
};

export default imageUploader;
