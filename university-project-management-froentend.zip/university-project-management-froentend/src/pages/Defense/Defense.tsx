import Breadcrumb from "../../components/Breadcrumbs/Breadcrumb";
import TableThree from "../../components/Tables/TableThree";
import DefaultLayout from "../../layout/DefaultLayout";


const Defense = () => {
    return (
        <div>
            <DefaultLayout>
                <Breadcrumb pageName="Defense" />
                <TableThree />
            </DefaultLayout>
        </div>
    );
};

export default Defense;