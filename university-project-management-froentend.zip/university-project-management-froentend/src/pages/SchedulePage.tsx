import { useEffect, useState } from "react";
import Breadcrumb from "../components/Breadcrumbs/Breadcrumb";
import FinalDefenseModal from "../components/Modal/FinalDefenseModal";
import PreDefense from "../components/Modal/PreDefense";
import DefaultLayout from "../layout/DefaultLayout";
import api from "../Utilities/api";


interface User {
    email: string;
    role: string;
    name: string;
    id: string;
}
const SchedulePage = () => {
    const [userInfo, setUserInfo] = useState<any>({});
    const user: User | null = JSON.parse(localStorage.getItem("user-info") || "null") as User | null;

    useEffect(() => {
        const fetchData = async () => {
            if (user?.email) {
                try {
                    const res = await api.get(`/get-student-by-email/${user?.email}`);
                    setUserInfo(res?.data);
                } catch (error) {
                    console.log("error", error);
                }
            }
        };

        fetchData();
    }, []);

    console.log('sssssssssssss', userInfo);

    return (
        <DefaultLayout>
            <Breadcrumb pageName="Project Schedule" />
            <div className=" bg-base-200 dark:bg-black  py-10 px-0 lg:px-10">
                <div className="hero-content flex-col  lg:flex-row-reverse lg:justify-between">
                    <div>
                        <h1 className="text-center text-xl mb-2">Supervisor : {userInfo?.user?.supervisor?.name}</h1>
                        <img src={userInfo?.user?.supervisor?.user.profileImage ? userInfo?.user?.supervisor?.user?.profileImage : `https://e7.pngegg.com/pngimages/550/997/png-clipart-user-icon-foreigners-avatar-child-face.png`} className="max-w-sm rounded-lg shadow-2xl" />
                    </div>
                    <div className="pl-10">
                        <h1 className="text-4xl font-bold">Project Name</h1>
                        <p className="py-6 text-2xl">Submit Pre Defense</p>
                        <button onClick={() => {
                            const modal = document.getElementById('pre_defense_modal') as HTMLDialogElement | null;
                            if (modal) {
                                modal.showModal();
                            }
                        }} className="btn btn-primary">Click Here</button>

                        <div className="mt-5">

                            <p className="py-6 text-2xl">Submit Final Defense</p>
                            <button
                                onClick={() => {
                                    const modal = document.getElementById('final_defense_modal') as HTMLDialogElement | null;
                                    if (modal) {
                                        modal.showModal();
                                    }
                                }}

                                className="btn btn-primary">Click Here</button>
                        </div>
                    </div>

                </div>
            </div>

            <PreDefense userInfo={userInfo} />
            <FinalDefenseModal userInfo={userInfo} />
        </DefaultLayout>






    );
};

export default SchedulePage;