export type Defense = {
    id: any;
    studentId: number;
    projectLink: string;
    reportLink: string;
    pptLink: string;
};

