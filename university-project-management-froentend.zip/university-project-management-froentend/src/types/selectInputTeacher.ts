export interface TeacherType {
    label: string;
    value: any;
}