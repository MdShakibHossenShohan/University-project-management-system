export type Student = {
    id: any;
    name: string;
    user: any
};

