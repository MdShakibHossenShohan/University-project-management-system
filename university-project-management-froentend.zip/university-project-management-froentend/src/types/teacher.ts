export type Teacher = {
    id: any;
    name: string;
    user: any
};