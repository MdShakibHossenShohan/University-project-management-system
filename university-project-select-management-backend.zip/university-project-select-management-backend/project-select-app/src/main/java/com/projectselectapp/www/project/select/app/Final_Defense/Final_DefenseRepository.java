package com.projectselectapp.www.project.select.app.Final_Defense;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Final_DefenseRepository extends JpaRepository<Final_Defense,Long> {
}
