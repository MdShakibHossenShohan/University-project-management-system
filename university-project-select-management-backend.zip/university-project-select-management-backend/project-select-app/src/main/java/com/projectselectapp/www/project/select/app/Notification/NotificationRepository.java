package com.projectselectapp.www.project.select.app.Notification;


import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificationRepository extends JpaRepository<Notification,Long> {
}