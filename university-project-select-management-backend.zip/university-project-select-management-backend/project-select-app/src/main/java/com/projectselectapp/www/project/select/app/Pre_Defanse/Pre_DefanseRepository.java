package com.projectselectapp.www.project.select.app.Pre_Defanse;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Pre_DefanseRepository extends JpaRepository<Pre_Defense,Long> {
}