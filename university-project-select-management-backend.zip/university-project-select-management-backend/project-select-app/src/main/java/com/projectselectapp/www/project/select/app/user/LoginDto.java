package com.projectselectapp.www.project.select.app.user;


import lombok.Data;

@Data
public class LoginDto {
    private String email;
    private String password;

}
