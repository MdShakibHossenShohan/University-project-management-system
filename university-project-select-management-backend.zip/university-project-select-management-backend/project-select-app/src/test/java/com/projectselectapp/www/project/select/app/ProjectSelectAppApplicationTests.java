package com.projectselectapp.www.project.select.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectSelectAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
